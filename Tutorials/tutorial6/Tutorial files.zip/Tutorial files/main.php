

<html>
<head>
<title>
main.php
</title>
</head>

<body>

<b>WELCOME TO OUR PHP-MYSQL LAB</b>

<p>
The following operations refer to a MySQL database called guest
<p>
<b>MENU</b>
<p>


1. <a href="print_sp.php"> print contents of the table sp (shippments)</a> <p>
2. <a href="get_table_name.php"> print contents of given table </a> <p>
3. <a href="http://google.com"> link to Google</a>

</body>

</html>
