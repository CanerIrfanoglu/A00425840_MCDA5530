	<?php
        $host="localhost";
        $user = "guest1";  // your user name
	$pass = "guest1";  // your password
	$db = "guest";  // the name of your database
	?>
   
  
