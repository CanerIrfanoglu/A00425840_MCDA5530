<html>
<head>
<title>
get_table_name.php
</title>
</head>
<body>


<form action="print_table.php" method="POST">
<b>Enter the name of the table you want to post:</b>


<input type="text" name="table">
<p>
	
<input type="submit" value="Hit">
</form>

<p>
<a href="main.php"> back to MAIN menu</a>

</body>
</html>

