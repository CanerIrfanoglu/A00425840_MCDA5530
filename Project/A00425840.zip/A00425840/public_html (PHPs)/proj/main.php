<html>
<head> <title> Main Page</title> </head> 
<body>
<center>
<h1>WELCOME</h1> <br>
<h3>Click on the below links to access the corresponding pages</h3>

<a href="show_tables.php">Show Tables</a><br>
<a href="add_article.php">Add New Article</a><br>
<a href="add_customer.php">Add New Customer</a><br>
<a href="create_new_transaction.php">Add New Transaction</a><br>
<a href="cancel_transaction.php">Cancel Transaction</a><br>

<?php


?>
</center>

</body>
</html>

