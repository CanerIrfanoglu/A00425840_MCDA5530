	<?php
        $host="localhost";
        $user = "v_govindan";  // your user name
	$pass = "A00429120";  // your password
	$db = "v_govindan";  // the name of your database
	?>
